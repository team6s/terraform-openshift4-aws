# Cloud Credential Operator utility

The ccoctl tool provides various commands to assist with the creating and maintenance of
cloud credentials from outside the cluster (necessary when CCO is put in "Manual" mode).

To learn more about OpenShift, visit [docs.openshift.com](https://docs.openshift.com)
and select the version of OpenShift you are using.

## Installing the tools

After extracting this archive, move the `ccoctl` binary to a location on your
PATH such as `/usr/local/bin`, or keep it in a temporary directory and
reference it via `./ccoctl`.

## License

OpenShift is licensed under the Apache Public License 2.0. The source code for this
program is [located on github](https://github.com/openshift/cloud-credential-operator).
